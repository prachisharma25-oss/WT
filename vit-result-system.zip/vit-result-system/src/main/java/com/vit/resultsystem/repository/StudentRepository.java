package com.vit.resultsystem.repository;

import com.vit.resultsystem.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {

    Optional<Student> findByRegNumber(String regNumber);

    Optional<Student> findByEmail(String email);

    List<Student> findByDepartment(String department);

    List<Student> findBySemester(String semester);

    boolean existsByRegNumber(String regNumber);

    boolean existsByEmail(String email);
}
