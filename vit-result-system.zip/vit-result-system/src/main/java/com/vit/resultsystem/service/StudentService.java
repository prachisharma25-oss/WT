package com.vit.resultsystem.service;

import com.vit.resultsystem.dto.StudentDTO;
import com.vit.resultsystem.entity.Student;
import com.vit.resultsystem.exception.DuplicateResourceException;
import com.vit.resultsystem.exception.ResourceNotFoundException;
import com.vit.resultsystem.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class StudentService {

    private final StudentRepository studentRepository;

    @Transactional
    public StudentDTO createStudent(StudentDTO dto) {
        log.info("Creating student with regNumber: {}", dto.getRegNumber());

        if (studentRepository.existsByRegNumber(dto.getRegNumber())) {
            throw new DuplicateResourceException("Student with reg number " + dto.getRegNumber() + " already exists");
        }
        if (dto.getEmail() != null && studentRepository.existsByEmail(dto.getEmail())) {
            throw new DuplicateResourceException("Student with email " + dto.getEmail() + " already exists");
        }

        Student student = toEntity(dto);
        Student saved = studentRepository.save(student);
        log.info("Student created with ID: {}", saved.getId());
        return toDTO(saved);
    }

    @Transactional(readOnly = true)
    public List<StudentDTO> getAllStudents() {
        return studentRepository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public StudentDTO getStudentById(Long id) {
        return toDTO(findStudentById(id));
    }

    @Transactional(readOnly = true)
    public StudentDTO getStudentByRegNumber(String regNumber) {
        Student student = studentRepository.findByRegNumber(regNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with reg number: " + regNumber));
        return toDTO(student);
    }

    @Transactional(readOnly = true)
    public List<StudentDTO> getStudentsByDepartment(String department) {
        return studentRepository.findByDepartment(department)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public StudentDTO updateStudent(Long id, StudentDTO dto) {
        Student student = findStudentById(id);

        if (!student.getRegNumber().equals(dto.getRegNumber()) &&
                studentRepository.existsByRegNumber(dto.getRegNumber())) {
            throw new DuplicateResourceException("Registration number already in use");
        }

        student.setRegNumber(dto.getRegNumber());
        student.setName(dto.getName());
        student.setDepartment(dto.getDepartment());
        student.setSemester(dto.getSemester());
        student.setEmail(dto.getEmail());
        student.setAcademicYear(dto.getAcademicYear());

        return toDTO(studentRepository.save(student));
    }

    @Transactional
    public void deleteStudent(Long id) {
        if (!studentRepository.existsById(id)) {
            throw new ResourceNotFoundException("Student not found with ID: " + id);
        }
        studentRepository.deleteById(id);
        log.info("Student deleted with ID: {}", id);
    }

    // ---- Helpers ----

    public Student findStudentById(Long id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with ID: " + id));
    }

    private StudentDTO toDTO(Student s) {
        return StudentDTO.builder()
                .id(s.getId())
                .regNumber(s.getRegNumber())
                .name(s.getName())
                .department(s.getDepartment())
                .semester(s.getSemester())
                .email(s.getEmail())
                .academicYear(s.getAcademicYear())
                .build();
    }

    private Student toEntity(StudentDTO dto) {
        return Student.builder()
                .regNumber(dto.getRegNumber())
                .name(dto.getName())
                .department(dto.getDepartment())
                .semester(dto.getSemester())
                .email(dto.getEmail())
                .academicYear(dto.getAcademicYear())
                .build();
    }
}
