package com.vit.resultsystem.controller;

import com.vit.resultsystem.dto.ApiResponse;
import com.vit.resultsystem.dto.StudentDTO;
import com.vit.resultsystem.service.StudentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/students")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class StudentController {

    private final StudentService studentService;

    /** POST /api/students - Register a new student */
    @PostMapping
    public ResponseEntity<ApiResponse<StudentDTO>> createStudent(@Valid @RequestBody StudentDTO dto) {
        StudentDTO created = studentService.createStudent(dto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Student registered successfully", created));
    }

    /** GET /api/students - Get all students */
    @GetMapping
    public ResponseEntity<ApiResponse<List<StudentDTO>>> getAllStudents() {
        return ResponseEntity.ok(ApiResponse.success("Students fetched", studentService.getAllStudents()));
    }

    /** GET /api/students/{id} - Get student by ID */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<StudentDTO>> getStudentById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Student found", studentService.getStudentById(id)));
    }

    /** GET /api/students/reg/{regNumber} - Get by registration number */
    @GetMapping("/reg/{regNumber}")
    public ResponseEntity<ApiResponse<StudentDTO>> getByRegNumber(@PathVariable String regNumber) {
        return ResponseEntity.ok(ApiResponse.success("Student found", studentService.getStudentByRegNumber(regNumber)));
    }

    /** GET /api/students/department/{dept} - Get by department */
    @GetMapping("/department/{dept}")
    public ResponseEntity<ApiResponse<List<StudentDTO>>> getByDepartment(@PathVariable String dept) {
        return ResponseEntity.ok(ApiResponse.success("Students fetched", studentService.getStudentsByDepartment(dept)));
    }

    /** PUT /api/students/{id} - Update student */
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<StudentDTO>> updateStudent(
            @PathVariable Long id,
            @Valid @RequestBody StudentDTO dto) {
        return ResponseEntity.ok(ApiResponse.success("Student updated", studentService.updateStudent(id, dto)));
    }

    /** DELETE /api/students/{id} - Delete student */
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteStudent(@PathVariable Long id) {
        studentService.deleteStudent(id);
        return ResponseEntity.ok(ApiResponse.success("Student deleted", null));
    }
}
