package com.vit.resultsystem.service;

import com.vit.resultsystem.dto.ResultRequestDTO;
import com.vit.resultsystem.dto.ResultResponseDTO;
import com.vit.resultsystem.entity.Result;
import com.vit.resultsystem.entity.Student;
import com.vit.resultsystem.exception.DuplicateResourceException;
import com.vit.resultsystem.exception.ResourceNotFoundException;
import com.vit.resultsystem.repository.ResultRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ResultService {

    private final ResultRepository resultRepository;
    private final StudentService studentService;

    @Transactional
    public ResultResponseDTO createResult(ResultRequestDTO dto) {
        Student student = studentService.findStudentById(dto.getStudentId());

        if (resultRepository.findByStudentId(student.getId()).isPresent()) {
            throw new DuplicateResourceException("Result already exists for student: " + student.getRegNumber()
                    + ". Use PUT to update.");
        }

        Result result = buildResult(dto, student);
        Result saved = resultRepository.save(result);
        log.info("Result saved for student: {}", student.getRegNumber());
        return toResponseDTO(saved);
    }

    @Transactional(readOnly = true)
    public ResultResponseDTO getResultByStudentId(Long studentId) {
        Result result = resultRepository.findByStudentId(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Result not found for student ID: " + studentId));
        return toResponseDTO(result);
    }

    @Transactional(readOnly = true)
    public ResultResponseDTO getResultByRegNumber(String regNumber) {
        Result result = resultRepository.findByStudentRegNumber(regNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Result not found for reg number: " + regNumber));
        return toResponseDTO(result);
    }

    @Transactional(readOnly = true)
    public List<ResultResponseDTO> getAllResults() {
        return resultRepository.findAllOrderByPercentageDesc()
                .stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ResultResponseDTO> getResultsByStatus(String status) {
        return resultRepository.findByResultStatus(status.toUpperCase())
                .stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ResultResponseDTO> getResultsByDepartment(String department) {
        return resultRepository.findByDepartment(department)
                .stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public ResultResponseDTO updateResult(Long resultId, ResultRequestDTO dto) {
        Result existing = resultRepository.findById(resultId)
                .orElseThrow(() -> new ResourceNotFoundException("Result not found with ID: " + resultId));

        // Allow student reassignment if needed
        Student student = studentService.findStudentById(dto.getStudentId());
        existing.setStudent(student);

        updateResultFields(existing, dto);
        Result saved = resultRepository.save(existing);
        log.info("Result updated for student: {}", student.getRegNumber());
        return toResponseDTO(saved);
    }

    @Transactional
    public void deleteResult(Long resultId) {
        if (!resultRepository.existsById(resultId)) {
            throw new ResourceNotFoundException("Result not found with ID: " + resultId);
        }
        resultRepository.deleteById(resultId);
        log.info("Result deleted with ID: {}", resultId);
    }

    // ---- Helpers ----

    private Result buildResult(ResultRequestDTO dto, Student student) {
        Result result = new Result();
        result.setStudent(student);
        updateResultFields(result, dto);
        return result;
    }

    private void updateResultFields(Result result, ResultRequestDTO dto) {
        result.setMathMse(dto.getMathMse());
        result.setMathEse(dto.getMathEse());
        result.setPhysicsMse(dto.getPhysicsMse());
        result.setPhysicsEse(dto.getPhysicsEse());
        result.setDsMse(dto.getDsMse());
        result.setDsEse(dto.getDsEse());
        result.setOopMse(dto.getOopMse());
        result.setOopEse(dto.getOopEse());
        // @PrePersist / @PreUpdate will compute totals, grade, status
    }

    private ResultResponseDTO toResponseDTO(Result r) {
        Student s = r.getStudent();
        return ResultResponseDTO.builder()
                .resultId(r.getId())
                .studentId(s.getId())
                .regNumber(s.getRegNumber())
                .studentName(s.getName())
                .department(s.getDepartment())
                .semester(s.getSemester())
                .academicYear(s.getAcademicYear())
                .mathMse(r.getMathMse())
                .mathEse(r.getMathEse())
                .mathTotal(r.getMathTotal())
                .physicsMse(r.getPhysicsMse())
                .physicsEse(r.getPhysicsEse())
                .physicsTotal(r.getPhysicsTotal())
                .dsMse(r.getDsMse())
                .dsEse(r.getDsEse())
                .dsTotal(r.getDsTotal())
                .oopMse(r.getOopMse())
                .oopEse(r.getOopEse())
                .oopTotal(r.getOopTotal())
                .overallTotal(r.getOverallTotal())
                .percentage(r.getPercentage())
                .grade(r.getGrade())
                .resultStatus(r.getResultStatus())
                .build();
    }
}
