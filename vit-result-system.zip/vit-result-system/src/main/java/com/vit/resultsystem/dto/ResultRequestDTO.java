package com.vit.resultsystem.dto;

import jakarta.validation.constraints.*;

public class ResultRequestDTO {

    @NotNull(message = "Student ID is required")
    private Long studentId;

    @NotNull @DecimalMin("0.0") @DecimalMax("30.0")
    private Double mathMse;

    @NotNull @DecimalMin("0.0") @DecimalMax("70.0")
    private Double mathEse;

    @NotNull @DecimalMin("0.0") @DecimalMax("30.0")
    private Double physicsMse;

    @NotNull @DecimalMin("0.0") @DecimalMax("70.0")
    private Double physicsEse;

    @NotNull @DecimalMin("0.0") @DecimalMax("30.0")
    private Double dsMse;

    @NotNull @DecimalMin("0.0") @DecimalMax("70.0")
    private Double dsEse;

    @NotNull @DecimalMin("0.0") @DecimalMax("30.0")
    private Double oopMse;

    @NotNull @DecimalMin("0.0") @DecimalMax("70.0")
    private Double oopEse;

    public ResultRequestDTO() {}

    // Getters & Setters
    public Long getStudentId() { return studentId; }
    public void setStudentId(Long studentId) { this.studentId = studentId; }

    public Double getMathMse() { return mathMse; }
    public void setMathMse(Double mathMse) { this.mathMse = mathMse; }

    public Double getMathEse() { return mathEse; }
    public void setMathEse(Double mathEse) { this.mathEse = mathEse; }

    public Double getPhysicsMse() { return physicsMse; }
    public void setPhysicsMse(Double physicsMse) { this.physicsMse = physicsMse; }

    public Double getPhysicsEse() { return physicsEse; }
    public void setPhysicsEse(Double physicsEse) { this.physicsEse = physicsEse; }

    public Double getDsMse() { return dsMse; }
    public void setDsMse(Double dsMse) { this.dsMse = dsMse; }

    public Double getDsEse() { return dsEse; }
    public void setDsEse(Double dsEse) { this.dsEse = dsEse; }

    public Double getOopMse() { return oopMse; }
    public void setOopMse(Double oopMse) { this.oopMse = oopMse; }

    public Double getOopEse() { return oopEse; }
    public void setOopEse(Double oopEse) { this.oopEse = oopEse; }
}
