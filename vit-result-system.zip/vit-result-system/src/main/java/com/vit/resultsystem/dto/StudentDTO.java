package com.vit.resultsystem.dto;

import jakarta.validation.constraints.*;

public class StudentDTO {

    private Long id;

    @NotBlank(message = "Registration number is required")
    private String regNumber;

    @NotBlank(message = "Student name is required")
    private String name;

    @NotBlank(message = "Department is required")
    private String department;

    @NotBlank(message = "Semester is required")
    private String semester;

    @Email(message = "Invalid email format")
    private String email;

    private String academicYear;

    public StudentDTO() {}

    public StudentDTO(Long id, String regNumber, String name, String department,
                      String semester, String email, String academicYear) {
        this.id = id;
        this.regNumber = regNumber;
        this.name = name;
        this.department = department;
        this.semester = semester;
        this.email = email;
        this.academicYear = academicYear;
    }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getRegNumber() { return regNumber; }
    public void setRegNumber(String regNumber) { this.regNumber = regNumber; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getAcademicYear() { return academicYear; }
    public void setAcademicYear(String academicYear) { this.academicYear = academicYear; }

    // Builder
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long id;
        private String regNumber, name, department, semester, email, academicYear;

        public Builder id(Long v) { this.id = v; return this; }
        public Builder regNumber(String v) { this.regNumber = v; return this; }
        public Builder name(String v) { this.name = v; return this; }
        public Builder department(String v) { this.department = v; return this; }
        public Builder semester(String v) { this.semester = v; return this; }
        public Builder email(String v) { this.email = v; return this; }
        public Builder academicYear(String v) { this.academicYear = v; return this; }

        public StudentDTO build() {
            return new StudentDTO(id, regNumber, name, department, semester, email, academicYear);
        }
    }
}
