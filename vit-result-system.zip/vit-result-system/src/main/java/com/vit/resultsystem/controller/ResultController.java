package com.vit.resultsystem.controller;

import com.vit.resultsystem.dto.ApiResponse;
import com.vit.resultsystem.dto.ResultRequestDTO;
import com.vit.resultsystem.dto.ResultResponseDTO;
import com.vit.resultsystem.service.ResultService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/results")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class ResultController {

    private final ResultService resultService;

    /** POST /api/results - Submit result for a student */
    @PostMapping
    public ResponseEntity<ApiResponse<ResultResponseDTO>> createResult(
            @Valid @RequestBody ResultRequestDTO dto) {
        ResultResponseDTO result = resultService.createResult(dto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Result submitted successfully", result));
    }

    /** GET /api/results - Get all results (ranked by percentage) */
    @GetMapping
    public ResponseEntity<ApiResponse<List<ResultResponseDTO>>> getAllResults() {
        return ResponseEntity.ok(ApiResponse.success("Results fetched", resultService.getAllResults()));
    }

    /** GET /api/results/{id} - Get result by result ID */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ResultResponseDTO>> getResultById(@PathVariable Long id) {
        // We reuse findByStudentId since IDs are same in 1-to-1 case; use a direct lookup
        return ResponseEntity.ok(ApiResponse.success("Result found",
                resultService.getResultByStudentId(id)));
    }

    /** GET /api/results/student/{studentId} - Get result by student ID */
    @GetMapping("/student/{studentId}")
    public ResponseEntity<ApiResponse<ResultResponseDTO>> getResultByStudentId(
            @PathVariable Long studentId) {
        return ResponseEntity.ok(ApiResponse.success("Result found",
                resultService.getResultByStudentId(studentId)));
    }

    /** GET /api/results/reg/{regNumber} - Get result by registration number */
    @GetMapping("/reg/{regNumber}")
    public ResponseEntity<ApiResponse<ResultResponseDTO>> getResultByRegNumber(
            @PathVariable String regNumber) {
        return ResponseEntity.ok(ApiResponse.success("Result found",
                resultService.getResultByRegNumber(regNumber)));
    }

    /** GET /api/results/status/{status} - Filter by PASS/FAIL */
    @GetMapping("/status/{status}")
    public ResponseEntity<ApiResponse<List<ResultResponseDTO>>> getResultsByStatus(
            @PathVariable String status) {
        return ResponseEntity.ok(ApiResponse.success("Results fetched",
                resultService.getResultsByStatus(status)));
    }

    /** GET /api/results/department/{dept} - Filter by department */
    @GetMapping("/department/{dept}")
    public ResponseEntity<ApiResponse<List<ResultResponseDTO>>> getResultsByDepartment(
            @PathVariable String dept) {
        return ResponseEntity.ok(ApiResponse.success("Results fetched",
                resultService.getResultsByDepartment(dept)));
    }

    /** PUT /api/results/{id} - Update an existing result */
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<ResultResponseDTO>> updateResult(
            @PathVariable Long id,
            @Valid @RequestBody ResultRequestDTO dto) {
        return ResponseEntity.ok(ApiResponse.success("Result updated",
                resultService.updateResult(id, dto)));
    }

    /** DELETE /api/results/{id} - Delete a result */
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteResult(@PathVariable Long id) {
        resultService.deleteResult(id);
        return ResponseEntity.ok(ApiResponse.success("Result deleted", null));
    }
}
