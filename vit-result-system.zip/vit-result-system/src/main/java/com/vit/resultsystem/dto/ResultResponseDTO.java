package com.vit.resultsystem.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ResultResponseDTO {

    private Long resultId;

    // Student Info
    private Long studentId;
    private String regNumber;
    private String studentName;
    private String department;
    private String semester;
    private String academicYear;

    // Mathematics
    private Double mathMse;
    private Double mathEse;
    private Double mathTotal;

    // Physics
    private Double physicsMse;
    private Double physicsEse;
    private Double physicsTotal;

    // Data Structures
    private Double dsMse;
    private Double dsEse;
    private Double dsTotal;

    // OOP
    private Double oopMse;
    private Double oopEse;
    private Double oopTotal;

    // Summary
    private Double overallTotal;
    private Double percentage;
    private String grade;
    private String resultStatus;
}
