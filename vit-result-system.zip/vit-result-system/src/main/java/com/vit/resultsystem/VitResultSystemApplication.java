package com.vit.resultsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VitResultSystemApplication {
    public static void main(String[] args) {
        SpringApplication.run(VitResultSystemApplication.class, args);
    }
}
