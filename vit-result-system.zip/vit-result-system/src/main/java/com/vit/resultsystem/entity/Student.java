package com.vit.resultsystem.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "students")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Registration number is required")
    @Column(name = "reg_number", unique = true, nullable = false, length = 20)
    private String regNumber;

    @NotBlank(message = "Student name is required")
    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @NotBlank(message = "Department is required")
    @Column(name = "department", nullable = false, length = 50)
    private String department;

    @NotBlank(message = "Semester is required")
    @Column(name = "semester", nullable = false, length = 10)
    private String semester;

    @Email(message = "Invalid email format")
    @Column(name = "email", unique = true, length = 100)
    private String email;

    @Column(name = "academic_year", length = 20)
    private String academicYear;

    @OneToMany(mappedBy = "student", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private List<Result> results = new ArrayList<>();

    // ---- Constructors ----
    public Student() {}

    public Student(Long id, String regNumber, String name, String department,
                   String semester, String email, String academicYear) {
        this.id = id;
        this.regNumber = regNumber;
        this.name = name;
        this.department = department;
        this.semester = semester;
        this.email = email;
        this.academicYear = academicYear;
    }

    // ---- Getters & Setters ----
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getRegNumber() { return regNumber; }
    public void setRegNumber(String regNumber) { this.regNumber = regNumber; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getAcademicYear() { return academicYear; }
    public void setAcademicYear(String academicYear) { this.academicYear = academicYear; }

    public List<Result> getResults() { return results; }
    public void setResults(List<Result> results) { this.results = results; }

    // ---- Builder ----
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long id;
        private String regNumber, name, department, semester, email, academicYear;

        public Builder id(Long id) { this.id = id; return this; }
        public Builder regNumber(String v) { this.regNumber = v; return this; }
        public Builder name(String v) { this.name = v; return this; }
        public Builder department(String v) { this.department = v; return this; }
        public Builder semester(String v) { this.semester = v; return this; }
        public Builder email(String v) { this.email = v; return this; }
        public Builder academicYear(String v) { this.academicYear = v; return this; }

        public Student build() {
            return new Student(id, regNumber, name, department, semester, email, academicYear);
        }
    }
}
