package com.vit.resultsystem.repository;

import com.vit.resultsystem.entity.Result;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ResultRepository extends JpaRepository<Result, Long> {

    Optional<Result> findByStudentId(Long studentId);

    Optional<Result> findByStudentRegNumber(String regNumber);

    List<Result> findByResultStatus(String resultStatus);

    @Query("SELECT r FROM Result r WHERE r.student.department = :dept")
    List<Result> findByDepartment(@Param("dept") String department);

    @Query("SELECT r FROM Result r WHERE r.student.semester = :sem")
    List<Result> findBySemester(@Param("sem") String semester);

    @Query("SELECT r FROM Result r ORDER BY r.percentage DESC")
    List<Result> findAllOrderByPercentageDesc();
}
