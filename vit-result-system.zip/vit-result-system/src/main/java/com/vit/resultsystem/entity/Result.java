package com.vit.resultsystem.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "results")
public class Result {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    // Subject 1 - Mathematics
    @NotNull(message = "Math MSE marks required")
    @DecimalMin("0.0") @DecimalMax("30.0")
    @Column(name = "math_mse", nullable = false)
    private Double mathMse;

    @NotNull(message = "Math ESE marks required")
    @DecimalMin("0.0") @DecimalMax("70.0")
    @Column(name = "math_ese", nullable = false)
    private Double mathEse;

    // Subject 2 - Physics
    @NotNull(message = "Physics MSE marks required")
    @DecimalMin("0.0") @DecimalMax("30.0")
    @Column(name = "physics_mse", nullable = false)
    private Double physicsMse;

    @NotNull(message = "Physics ESE marks required")
    @DecimalMin("0.0") @DecimalMax("70.0")
    @Column(name = "physics_ese", nullable = false)
    private Double physicsEse;

    // Subject 3 - Data Structures
    @NotNull(message = "DS MSE marks required")
    @DecimalMin("0.0") @DecimalMax("30.0")
    @Column(name = "ds_mse", nullable = false)
    private Double dsMse;

    @NotNull(message = "DS ESE marks required")
    @DecimalMin("0.0") @DecimalMax("70.0")
    @Column(name = "ds_ese", nullable = false)
    private Double dsEse;

    // Subject 4 - OOP
    @NotNull(message = "OOP MSE marks required")
    @DecimalMin("0.0") @DecimalMax("30.0")
    @Column(name = "oop_mse", nullable = false)
    private Double oopMse;

    @NotNull(message = "OOP ESE marks required")
    @DecimalMin("0.0") @DecimalMax("70.0")
    @Column(name = "oop_ese", nullable = false)
    private Double oopEse;

    // Computed fields
    @Column(name = "math_total")    private Double mathTotal;
    @Column(name = "physics_total") private Double physicsTotal;
    @Column(name = "ds_total")      private Double dsTotal;
    @Column(name = "oop_total")     private Double oopTotal;
    @Column(name = "overall_total") private Double overallTotal;
    @Column(name = "percentage")    private Double percentage;
    @Column(name = "grade", length = 5)      private String grade;
    @Column(name = "result_status", length = 10) private String resultStatus;

    public Result() {}

    // ---- Lifecycle: auto-compute on save/update ----
    @PrePersist
    @PreUpdate
    public void calculateResults() {
        this.mathTotal    = round2(mathMse + mathEse);
        this.physicsTotal = round2(physicsMse + physicsEse);
        this.dsTotal      = round2(dsMse + dsEse);
        this.oopTotal     = round2(oopMse + oopEse);
        this.overallTotal = round2(mathTotal + physicsTotal + dsTotal + oopTotal);
        this.percentage   = round2(overallTotal / 4.0);
        this.grade        = calcGrade(percentage);
        this.resultStatus = (mathTotal >= 40 && physicsTotal >= 40
                          && dsTotal >= 40 && oopTotal >= 40) ? "PASS" : "FAIL";
    }

    private Double round2(double v) { return Math.round(v * 100.0) / 100.0; }

    private String calcGrade(double p) {
        if (p >= 90) return "O";
        if (p >= 80) return "A+";
        if (p >= 70) return "A";
        if (p >= 60) return "B+";
        if (p >= 50) return "B";
        if (p >= 40) return "C";
        return "F";
    }

    // ---- Getters & Setters ----
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }

    public Double getMathMse() { return mathMse; }
    public void setMathMse(Double mathMse) { this.mathMse = mathMse; }

    public Double getMathEse() { return mathEse; }
    public void setMathEse(Double mathEse) { this.mathEse = mathEse; }

    public Double getPhysicsMse() { return physicsMse; }
    public void setPhysicsMse(Double physicsMse) { this.physicsMse = physicsMse; }

    public Double getPhysicsEse() { return physicsEse; }
    public void setPhysicsEse(Double physicsEse) { this.physicsEse = physicsEse; }

    public Double getDsMse() { return dsMse; }
    public void setDsMse(Double dsMse) { this.dsMse = dsMse; }

    public Double getDsEse() { return dsEse; }
    public void setDsEse(Double dsEse) { this.dsEse = dsEse; }

    public Double getOopMse() { return oopMse; }
    public void setOopMse(Double oopMse) { this.oopMse = oopMse; }

    public Double getOopEse() { return oopEse; }
    public void setOopEse(Double oopEse) { this.oopEse = oopEse; }

    public Double getMathTotal() { return mathTotal; }
    public void setMathTotal(Double mathTotal) { this.mathTotal = mathTotal; }

    public Double getPhysicsTotal() { return physicsTotal; }
    public void setPhysicsTotal(Double physicsTotal) { this.physicsTotal = physicsTotal; }

    public Double getDsTotal() { return dsTotal; }
    public void setDsTotal(Double dsTotal) { this.dsTotal = dsTotal; }

    public Double getOopTotal() { return oopTotal; }
    public void setOopTotal(Double oopTotal) { this.oopTotal = oopTotal; }

    public Double getOverallTotal() { return overallTotal; }
    public void setOverallTotal(Double overallTotal) { this.overallTotal = overallTotal; }

    public Double getPercentage() { return percentage; }
    public void setPercentage(Double percentage) { this.percentage = percentage; }

    public String getGrade() { return grade; }
    public void setGrade(String grade) { this.grade = grade; }

    public String getResultStatus() { return resultStatus; }
    public void setResultStatus(String resultStatus) { this.resultStatus = resultStatus; }
}
