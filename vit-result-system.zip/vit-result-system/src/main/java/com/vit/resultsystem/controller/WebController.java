package com.vit.resultsystem.controller;

import com.vit.resultsystem.dto.ResultResponseDTO;
import com.vit.resultsystem.dto.StudentDTO;
import com.vit.resultsystem.exception.ResourceNotFoundException;
import com.vit.resultsystem.service.ResultService;
import com.vit.resultsystem.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class WebController {

    private final StudentService studentService;
    private final ResultService resultService;

    /** Home / Dashboard */
    @GetMapping("/")
    public String home(Model model) {
        List<ResultResponseDTO> results = resultService.getAllResults();
        long passCount = results.stream().filter(r -> "PASS".equals(r.getResultStatus())).count();
        long failCount = results.stream().filter(r -> "FAIL".equals(r.getResultStatus())).count();

        model.addAttribute("totalStudents", studentService.getAllStudents().size());
        model.addAttribute("totalResults", results.size());
        model.addAttribute("passCount", passCount);
        model.addAttribute("failCount", failCount);
        model.addAttribute("recentResults", results.stream().limit(5).toList());
        return "index";
    }

    /** All students list */
    @GetMapping("/students")
    public String students(Model model) {
        model.addAttribute("students", studentService.getAllStudents());
        return "students";
    }

    /** All results / marksheet list */
    @GetMapping("/results")
    public String results(Model model) {
        model.addAttribute("results", resultService.getAllResults());
        return "results";
    }

    /** View single result marksheet */
    @GetMapping("/results/view")
    public String viewResult(@RequestParam String regNumber, Model model) {
        try {
            ResultResponseDTO result = resultService.getResultByRegNumber(regNumber);
            model.addAttribute("result", result);
            return "marksheet";
        } catch (ResourceNotFoundException e) {
            model.addAttribute("error", e.getMessage());
            return "error";
        }
    }

    /** Search result by reg number */
    @GetMapping("/search")
    public String search(Model model) {
        return "search";
    }
}
