-- Optional: Run this to seed sample data after the app creates tables
-- Execute in MySQL Workbench or CLI after first boot

INSERT IGNORE INTO students (reg_number, name, department, semester, email, academic_year)
VALUES
  ('22BCE1234', 'Aarav Sharma',   'CSE', 'Semester 3', 'aarav@vit.ac.in',   '2024-25'),
  ('22BCE1235', 'Priya Nair',     'CSE', 'Semester 3', 'priya@vit.ac.in',   '2024-25'),
  ('22ECE2001', 'Rohan Verma',    'ECE', 'Semester 3', 'rohan@vit.ac.in',   '2024-25'),
  ('22MEC3001', 'Sneha Pillai',   'MEC', 'Semester 3', 'sneha@vit.ac.in',   '2024-25');

-- After inserting students, get their IDs and insert results
-- Replace 1,2,3,4 with actual student IDs from the students table

INSERT IGNORE INTO results
  (student_id, math_mse, math_ese, physics_mse, physics_ese, ds_mse, ds_ese, oop_mse, oop_ese)
SELECT id, 25, 58, 22, 62, 28, 65, 26, 60 FROM students WHERE reg_number = '22BCE1234';

INSERT IGNORE INTO results
  (student_id, math_mse, math_ese, physics_mse, physics_ese, ds_mse, ds_ese, oop_mse, oop_ese)
SELECT id, 20, 45, 18, 40, 15, 35, 20, 42 FROM students WHERE reg_number = '22BCE1235';

INSERT IGNORE INTO results
  (student_id, math_mse, math_ese, physics_mse, physics_ese, ds_mse, ds_ese, oop_mse, oop_ese)
SELECT id, 30, 68, 27, 65, 29, 70, 30, 69 FROM students WHERE reg_number = '22ECE2001';

INSERT IGNORE INTO results
  (student_id, math_mse, math_ese, physics_mse, physics_ese, ds_mse, ds_ese, oop_mse, oop_ese)
SELECT id, 12, 28, 10, 25, 8, 22, 14, 30 FROM students WHERE reg_number = '22MEC3001';
