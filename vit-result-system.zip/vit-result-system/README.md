# VIT Student Semester Result Management System

A full-stack web application built with **Spring Boot**, **MySQL**, and **Thymeleaf** to manage VIT student semester results.

## Subjects Covered
| # | Subject | Code | MSE (30%) | ESE (70%) | Total |
|---|---------|------|-----------|-----------|-------|
| 1 | Mathematics | MAT101 | 30 | 70 | 100 |
| 2 | Engineering Physics | PHY101 | 30 | 70 | 100 |
| 3 | Data Structures | CSE201 | 30 | 70 | 100 |
| 4 | Object Oriented Programming | CSE202 | 30 | 70 | 100 |

**Max Total: 400 marks**

## Grade Scale
| Grade | Percentage |
|-------|------------|
| O | ≥ 90% |
| A+ | ≥ 80% |
| A | ≥ 70% |
| B+ | ≥ 60% |
| B | ≥ 50% |
| C | ≥ 40% |
| F | < 40% |

Pass Condition: All 4 subjects must have ≥ 40 marks.

---

## Prerequisites
- Java 17+
- Maven 3.8+
- MySQL 8.0+
- Postman (for API testing)

---

## How to Run

### Step 1: MySQL Setup
```sql
CREATE DATABASE vit_result_db;
-- Spring Boot will auto-create tables on first run
```

### Step 2: Configure DB credentials
Edit `src/main/resources/application.properties`:
```properties
spring.datasource.username=root
spring.datasource.password=your_password
```

### Step 3: Build and Run
```bash
cd vit-result-system
mvn clean install
mvn spring-boot:run
```

App runs at: **http://localhost:8080**

---

## REST API Endpoints

### Students
| Method | URL | Description |
|--------|-----|-------------|
| POST | `/api/students` | Register new student |
| GET | `/api/students` | Get all students |
| GET | `/api/students/{id}` | Get by ID |
| GET | `/api/students/reg/{regNumber}` | Get by reg number |
| GET | `/api/students/department/{dept}` | Get by department |
| PUT | `/api/students/{id}` | Update student |
| DELETE | `/api/students/{id}` | Delete student |

### Results
| Method | URL | Description |
|--------|-----|-------------|
| POST | `/api/results` | Submit marks |
| GET | `/api/results` | All results (ranked) |
| GET | `/api/results/student/{studentId}` | Result by student ID |
| GET | `/api/results/reg/{regNumber}` | Result by reg number |
| GET | `/api/results/status/{PASS\|FAIL}` | Filter by status |
| GET | `/api/results/department/{dept}` | Filter by department |
| PUT | `/api/results/{id}` | Update result |
| DELETE | `/api/results/{id}` | Delete result |

---

## Web UI Pages
| URL | Page |
|-----|------|
| `http://localhost:8080/` | Dashboard |
| `http://localhost:8080/students` | Student list |
| `http://localhost:8080/results` | Results ranked table |
| `http://localhost:8080/search` | Search by reg number |
| `http://localhost:8080/results/view?regNumber=22BCE1234` | Printable marksheet |
